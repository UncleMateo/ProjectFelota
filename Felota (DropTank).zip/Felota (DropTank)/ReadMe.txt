
	Simply install the contents of the zipped GameData folder into your KSP GameData folder.  

	In order for this patch to work you will need:
		• Wrapper DropTanks
		• TexturesUnlimited

